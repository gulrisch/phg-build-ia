"""
PHG BUILD IA — Générateur d'exports professionnels
PDF complet + Plan PNG + Fiche technique
"""
import math
import io
import os
from datetime import datetime

# ── DONNÉES DU PROJET (simulées depuis l'app) ──────────────────────────────
PROJECT = {
    "name": "Villa Cocody — Projet PHG",
    "client": "M. Konan Kouassi",
    "pays": "Côte d'Ivoire",
    "ville": "Abidjan — Cocody",
    "date": datetime.now().strftime("%d/%m/%Y"),
    "qualite": "Standard",
    "architecte": "PHG BUILD IA",
    "ref": "PHG-2025-0042",
}

ROOMS = [
    {"name": "Salon",      "icon": "S",  "x": 20,  "y": 20,  "w": 140, "h": 100, "color": (201,168,76)},
    {"name": "Cuisine",    "icon": "K",  "x": 160, "y": 20,  "w":  80, "h":  60, "color": (76,175,110)},
    {"name": "Chambre 1",  "icon": "C1", "x": 20,  "y": 120, "w": 100, "h":  80, "color": (122,171,201)},
    {"name": "Chambre 2",  "icon": "C2", "x": 120, "y": 120, "w": 100, "h":  80, "color": (122,171,201)},
    {"name": "SDB",        "icon": "SDB","x": 220, "y":  20, "w":  60, "h":  60, "color": (93,202,165)},
    {"name": "WC",         "icon": "WC", "x": 220, "y":  80, "w":  60, "h":  40, "color": (136,136,136)},
    {"name": "Couloir",    "icon": "—",  "x": 120, "y":  80, "w": 100, "h":  40, "color": (80,80,80)},
]
SCALE = 20  # px per meter

METRICS = {
    "surface_totale": 120.5,
    "surface_hab": 102.4,
    "perimetre": 44.0,
    "surface_murs": 396.0,
    "surface_toiture": 138.6,
    "nb_pieces": 7,
    "nb_fenetres": 7,
}

PRICES = {
    "par": 0.95, "cim": 5.2, "sable": 24, "grav": 27,
    "tole": 11, "tuile": 18, "fen": 145, "cable": 1.1,
    "pvc": 1.4, "maçon": 40, "elec": 55, "plom": 50,
    "cur": "FCFA",
}

MATERIALS = [
    {"n": "Parpaing creux 20",       "cat": "Murs",       "q": 20790, "u": "pce",  "pu": PRICES["par"],   "t": round(20790*PRICES["par"])},
    {"n": "Ciment Portland 35kg",    "cat": "Fondations", "q": 183,   "u": "sac",  "pu": PRICES["cim"],   "t": round(183*PRICES["cim"])},
    {"n": "Sable de construction",   "cat": "Fondations", "q": 9.1,   "u": "m³",   "pu": PRICES["sable"], "t": round(9.1*PRICES["sable"])},
    {"n": "Gravier",                 "cat": "Fondations", "q": 14.5,  "u": "m³",   "pu": PRICES["grav"],  "t": round(14.5*PRICES["grav"])},
    {"n": "Tuile béton",             "cat": "Toiture",    "q": 150,   "u": "m²",   "pu": PRICES["tuile"], "t": round(150*PRICES["tuile"])},
    {"n": "Fenêtre aluminium std",   "cat": "Menuiserie", "q": 7,     "u": "pce",  "pu": PRICES["fen"],   "t": round(7*PRICES["fen"])},
    {"n": "Câble électrique",        "cat": "Électricité","q": 723,   "u": "m",    "pu": PRICES["cable"], "t": round(723*PRICES["cable"])},
    {"n": "Tube PVC plomberie",      "cat": "Plomberie",  "q": 217,   "u": "m",    "pu": PRICES["pvc"],   "t": round(217*PRICES["pvc"])},
]

mat_total = sum(m["t"] for m in MATERIALS)
lab_total = round(METRICS["surface_totale"]/8*PRICES["maçon"] + METRICS["surface_totale"]/25*PRICES["elec"] + METRICS["surface_totale"]/30*PRICES["plom"])
log_total = round(mat_total * 0.03)
sub = mat_total + lab_total + log_total
risk = round(sub * 0.08)
total = sub + risk
CUR = PRICES["cur"]

COSTS = {
    "materiaux": mat_total,
    "main_oeuvre": lab_total,
    "logistique": log_total,
    "marge_risque": risk,
    "total": total,
}

ISSUES = [
    {"sev": "MOYEN",  "titre": "Couloir légèrement surdimensionné",       "sol": "Réduire de 0.5m pour gagner 5m² habitables"},
    {"sev": "OK",     "titre": "Orientation solaire conforme",             "sol": "Plan orienté correctement — aucune correction"},
    {"sev": "OK",     "titre": "Pièces humides groupées",                  "sol": "Cuisine et SDB adjacentes — plomberie optimisée"},
    {"sev": "INFO",   "titre": "Optimisation possible — fenêtres",        "sol": "Ajouter une fenêtre en Chambre 2 pour ventilation"},
]

SCORES = {"Budget": 78, "Constructibilite": 88, "Materiaux": 85, "Optimisation": 80, "Global": 83}

# ── IMPORTS PDF ──────────────────────────────────────────────────────────────
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm, mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak, Image as RLImage
)
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.graphics.shapes import Drawing, Rect, String, Line, Circle
from reportlab.graphics import renderPDF

# ── COULEURS PHG ─────────────────────────────────────────────────────────────
GOLD     = colors.HexColor("#C9A84C")
GOLD2    = colors.HexColor("#E8CC7A")
GOLD_DIM = colors.HexColor("#7A6330")
BLACK    = colors.HexColor("#0A0A0A")
DARK     = colors.HexColor("#141414")
PANEL    = colors.HexColor("#1C1C1C")
TEXT     = colors.HexColor("#EAE2D0")
DIM      = colors.HexColor("#888880")
OK       = colors.HexColor("#4CAF6E")
WARN     = colors.HexColor("#E8A94C")
ERR      = colors.HexColor("#C94C4C")
WHITE    = colors.white
PAGE_W, PAGE_H = A4

fmt_n = lambda n: f"{int(n):,}".replace(",", " ")

# ═══════════════════════════════════════════════════════════════════════
# 1. PLAN PNG — dessin du plan 2D
# ═══════════════════════════════════════════════════════════════════════
def generate_plan_png(output_path):
    try:
        from PIL import Image, ImageDraw, ImageFont
        W, H = 800, 520
        img = Image.new("RGB", (W, H), (8, 8, 8))
        draw = ImageDraw.Draw(img)

        OX, OY = 30, 30  # offset

        # Grille
        for gx in range(0, W, 20):
            draw.line([(gx, 0), (gx, H)], fill=(20, 20, 15), width=1)
        for gy in range(0, H, 20):
            draw.line([(0, gy), (W, gy)], fill=(20, 20, 15), width=1)

        # Contour global
        all_x = [r["x"] for r in ROOMS] + [r["x"]+r["w"] for r in ROOMS]
        all_y = [r["y"] for r in ROOMS] + [r["y"]+r["h"] for r in ROOMS]
        draw.rectangle([OX+min(all_x)-4, OY+min(all_y)-4,
                        OX+max(all_x)+4, OY+max(all_y)+4],
                       outline=(201, 168, 76), width=2)

        # Pièces
        for room in ROOMS:
            x1 = OX + room["x"]
            y1 = OY + room["y"]
            x2 = x1 + room["w"]
            y2 = y1 + room["h"]
            r, g, b = room["color"]
            draw.rectangle([x1, y1, x2, y2], fill=(r//6, g//6, b//6), outline=(r, g, b), width=1)

            # Label au centre
            cx, cy = (x1+x2)//2, (y1+y2)//2
            wm = room["w"]/SCALE
            hm = room["h"]/SCALE
            sm = wm*hm
            draw.text((cx, cy-8), room["name"], fill=(r, g, b), anchor="mm")
            draw.text((cx, cy+6), f"{wm:.1f}×{hm:.1f}m", fill=(200, 190, 170), anchor="mm")
            draw.text((cx, cy+16), f"{sm:.1f}m²", fill=(r, g, b), anchor="mm")

        # Nord
        draw.text((W-30, 20), "N", fill=(201, 168, 76))
        draw.line([(W-30, 35), (W-30, 55)], fill=(201, 168, 76), width=2)
        draw.polygon([(W-30, 30), (W-35, 45), (W-25, 45)], fill=(201, 168, 76))

        # Titre bas
        draw.rectangle([0, H-30, W, H], fill=(10, 8, 4))
        draw.text((20, H-20), f"PHG BUILD IA — {PROJECT['name']} — Échelle 1:{SCALE*5}", fill=(201, 168, 76))
        draw.text((W-20, H-20), f"Réf: {PROJECT['ref']}", fill=(120, 110, 80), anchor="rm")

        img.save(output_path, "PNG", dpi=(150, 150))
        return True
    except ImportError:
        return False

# ═══════════════════════════════════════════════════════════════════════
# 2. PDF COMPLET
# ═══════════════════════════════════════════════════════════════════════
def build_pdf(output_path, plan_png_path=None):

    def page_template(canv, doc):
        canv.saveState()
        # Fond noir
        canv.setFillColor(BLACK)
        canv.rect(0, 0, PAGE_W, PAGE_H, fill=1, stroke=0)
        # Bande dorée haut
        canv.setFillColor(GOLD)
        canv.rect(0, PAGE_H-8*mm, PAGE_W, 8*mm, fill=1, stroke=0)
        # Logo glyph haut gauche
        canv.setFillColor(BLACK)
        canv.setFont("Helvetica-Bold", 14)
        canv.drawString(8*mm, PAGE_H-5.5*mm, "PHG BUILD IA")
        # Ref haut droite
        canv.setFillColor(BLACK)
        canv.setFont("Helvetica", 9)
        canv.drawRightString(PAGE_W-8*mm, PAGE_H-5.5*mm, f"Réf: {PROJECT['ref']}")
        # Bande bas
        canv.setFillColor(DARK)
        canv.rect(0, 0, PAGE_W, 10*mm, fill=1, stroke=0)
        canv.setFillColor(DIM)
        canv.setFont("Helvetica", 7)
        canv.drawString(8*mm, 3.5*mm, f"PHG Éditions · Saint-Julien-en-Genevois · Document confidentiel · {PROJECT['date']}")
        canv.drawRightString(PAGE_W-8*mm, 3.5*mm, f"Page {doc.page}")
        canv.restoreState()

    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        topMargin=15*mm, bottomMargin=16*mm,
        leftMargin=12*mm, rightMargin=12*mm,
        title=f"PHG BUILD IA — {PROJECT['name']}",
        author="PHG Éditions",
    )

    styles = getSampleStyleSheet()
    def sty(name, **kw):
        base = styles.get(name, styles["Normal"])
        return ParagraphStyle(name+str(id(kw)), parent=base, **kw)

    gold_h1 = sty("Normal", fontSize=16, textColor=GOLD, fontName="Helvetica-Bold", spaceAfter=4, spaceBefore=8)
    gold_h2 = sty("Normal", fontSize=12, textColor=GOLD, fontName="Helvetica-Bold", spaceAfter=3, spaceBefore=6)
    gold_h3 = sty("Normal", fontSize=10, textColor=GOLD2, fontName="Helvetica-Bold", spaceAfter=2, spaceBefore=4)
    body_st = sty("Normal", fontSize=9, textColor=TEXT, fontName="Helvetica", spaceAfter=2, leading=14)
    dim_st  = sty("Normal", fontSize=8, textColor=DIM, fontName="Helvetica", spaceAfter=1)
    center_st = sty("Normal", fontSize=9, textColor=TEXT, fontName="Helvetica", alignment=TA_CENTER)

    story = []
    HR = lambda c=GOLD_DIM: HRFlowable(width="100%", thickness=0.5, color=c, spaceAfter=4, spaceBefore=4)

    # ── PAGE DE COUVERTURE ───────────────────────────────────────────────
    story.append(Spacer(1, 30*mm))
    # Grand glyph
    glyph_tbl = Table([[Paragraph('<font size="48" color="#C9A84C">𓂀</font>', sty("Normal", alignment=TA_CENTER))]], colWidths=[PAGE_W-24*mm])
    glyph_tbl.setStyle(TableStyle([("ALIGN",(0,0),(-1,-1),"CENTER")]))
    story.append(glyph_tbl)
    story.append(Spacer(1, 6*mm))

    story.append(Paragraph('<font size="28" color="#C9A84C"><b>PHG BUILD IA</b></font>', sty("Normal", alignment=TA_CENTER)))
    story.append(Paragraph('<font size="12" color="#888880">RAPPORT D\'ESTIMATION PROFESSIONNEL</font>', sty("Normal", alignment=TA_CENTER)))
    story.append(Spacer(1, 8*mm))
    story.append(HR(GOLD))
    story.append(Spacer(1, 4*mm))

    cover_data = [
        ["Projet",     PROJECT["name"]],
        ["Client",     PROJECT["client"]],
        ["Localisation", f"{PROJECT['ville']} · {PROJECT['pays']}"],
        ["Référence",  PROJECT["ref"]],
        ["Date",       PROJECT["date"]],
        ["Qualité",    PROJECT["qualite"]],
        ["Instrument", "PHG BUILD IA — Super Architecte IA"],
    ]
    cover_tbl = Table(cover_data, colWidths=[50*mm, 105*mm])
    cover_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(0,-1), DARK),
        ("BACKGROUND",(1,0),(1,-1), PANEL),
        ("TEXTCOLOR",(0,0),(0,-1), GOLD_DIM),
        ("TEXTCOLOR",(1,0),(1,-1), TEXT),
        ("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),
        ("FONTNAME",(1,0),(1,-1),"Helvetica"),
        ("FONTSIZE",(0,0),(-1,-1),9),
        ("ROWBACKGROUNDS",(0,0),(-1,-1),[DARK, PANEL]),
        ("GRID",(0,0),(-1,-1),0.3, colors.HexColor("#2A2A2A")),
        ("LEFTPADDING",(0,0),(-1,-1),8),
        ("RIGHTPADDING",(0,0),(-1,-1),8),
        ("TOPPADDING",(0,0),(-1,-1),5),
        ("BOTTOMPADDING",(0,0),(-1,-1),5),
    ]))
    story.append(cover_tbl)
    story.append(Spacer(1, 10*mm))
    story.append(Paragraph('<font size="9" color="#555550">Ce rapport a été généré automatiquement par PHG BUILD IA, l\'instrument de référence pour architectes, géomètres et particuliers. Il fournit une estimation professionnelle non réglementaire à titre indicatif.</font>', sty("Normal", alignment=TA_CENTER)))
    story.append(PageBreak())

    # ── PAGE 2 : PLAN 2D ────────────────────────────────────────────────
    story.append(Paragraph("Plan du projet", gold_h1))
    story.append(HR())
    if plan_png_path and os.path.exists(plan_png_path):
        img = RLImage(plan_png_path, width=165*mm, height=107*mm)
        story.append(img)
    else:
        # Plan vectoriel ReportLab si pas d'image
        plan_drawing = Drawing(165*mm, 100*mm)
        plan_drawing.add(Rect(0, 0, 165*mm, 100*mm, fillColor=colors.HexColor("#080808"), strokeColor=GOLD_DIM, strokeWidth=0.5))
        ox, oy = 10*mm, 5*mm
        sc = 0.8
        room_colors_rl = {
            "Salon":     colors.HexColor("#3A2A08"),
            "Cuisine":   colors.HexColor("#083A18"),
            "Chambre 1": colors.HexColor("#081828"),
            "Chambre 2": colors.HexColor("#081828"),
            "SDB":       colors.HexColor("#082820"),
            "WC":        colors.HexColor("#181818"),
            "Couloir":   colors.HexColor("#141414"),
        }
        for room in ROOMS:
            rx = ox + room["x"]*sc*mm
            ry = oy + (200 - room["y"] - room["h"])*sc*mm
            rw = room["w"]*sc*mm
            rh = room["h"]*sc*mm
            rc = room_colors_rl.get(room["name"], colors.HexColor("#1A1A14"))
            bc = colors.Color(room["color"][0]/255, room["color"][1]/255, room["color"][2]/255)
            plan_drawing.add(Rect(rx, ry, rw, rh, fillColor=rc, strokeColor=bc, strokeWidth=0.8))
            cx, cy = rx+rw/2, ry+rh/2
            plan_drawing.add(String(cx, cy+3, room["name"], fontSize=6, fillColor=colors.Color(room["color"][0]/255, room["color"][1]/255, room["color"][2]/255), textAnchor="middle"))
            wm = room["w"]/SCALE
            hm = room["h"]/SCALE
            plan_drawing.add(String(cx, cy-5, f"{wm:.1f}×{hm:.1f}m", fontSize=5, fillColor=colors.HexColor("#AAAAAA"), textAnchor="middle"))
        story.append(plan_drawing)

    story.append(Spacer(1, 3*mm))
    story.append(Paragraph(f'<font size="8" color="#555550">Plan 2D · Échelle indicative · Réf. {PROJECT["ref"]} · Généré par PHG BUILD IA</font>', sty("Normal", alignment=TA_CENTER)))
    story.append(Spacer(1, 4*mm))

    # Tableau pièces
    story.append(Paragraph("Détail des pièces", gold_h2))
    rooms_data = [["Pièce", "Largeur", "Profondeur", "Surface"]]
    total_surf = 0
    for room in ROOMS:
        wm = room["w"]/SCALE
        hm = room["h"]/SCALE
        sm = wm*hm
        total_surf += sm
        rooms_data.append([room["name"], f"{wm:.1f} m", f"{hm:.1f} m", f"{sm:.1f} m²"])
    rooms_data.append(["TOTAL", "", "", f"{total_surf:.1f} m²"])

    rooms_tbl = Table(rooms_data, colWidths=[55*mm, 35*mm, 35*mm, 40*mm])
    rooms_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0), colors.HexColor("#1A1408")),
        ("TEXTCOLOR",(0,0),(-1,0), GOLD),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("BACKGROUND",(0,-1),(-1,-1), colors.HexColor("#1A1408")),
        ("TEXTCOLOR",(0,-1),(-1,-1), GOLD),
        ("FONTNAME",(0,-1),(-1,-1),"Helvetica-Bold"),
        ("BACKGROUND",(0,1),(-1,-2), DARK),
        ("TEXTCOLOR",(0,1),(-1,-2), TEXT),
        ("ROWBACKGROUNDS",(0,1),(-1,-2),[DARK, PANEL]),
        ("FONTNAME",(0,1),(-1,-2),"Helvetica"),
        ("FONTSIZE",(0,0),(-1,-1),9),
        ("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#2A2A2A")),
        ("ALIGN",(1,0),(-1,-1),"CENTER"),
        ("LEFTPADDING",(0,0),(-1,-1),7),
        ("TOPPADDING",(0,0),(-1,-1),4),
        ("BOTTOMPADDING",(0,0),(-1,-1),4),
    ]))
    story.append(rooms_tbl)
    story.append(PageBreak())

    # ── PAGE 3 : MÉTRÉS ─────────────────────────────────────────────────
    story.append(Paragraph("Métrés architecte & Données techniques", gold_h1))
    story.append(HR())
    metrics_data = [
        ["Métré", "Valeur", "Métré", "Valeur"],
        ["SHOB (surface brute)", f"{METRICS['surface_totale']:.1f} m²", "Périmètre extérieur", f"{METRICS['perimetre']:.1f} m"],
        ["SHON (nette ~85%)", f"{METRICS['surface_hab']:.1f} m²", "Surface murs ext.", f"{METRICS['surface_murs']:.1f} m²"],
        ["Nb de pièces", str(METRICS["nb_pieces"]), "Surface toiture", f"{METRICS['surface_toiture']:.1f} m²"],
        ["Nb fenêtres estimé", str(METRICS["nb_fenetres"]) + " unités", "Volume murs béton", f"{METRICS['surface_murs']*0.20:.1f} m³"],
    ]
    met_tbl = Table(metrics_data, colWidths=[55*mm, 35*mm, 55*mm, 35*mm])
    met_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1A1408")),
        ("TEXTCOLOR",(0,0),(-1,0), GOLD),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("BACKGROUND",(0,1),(0,-1), colors.HexColor("#1A1408")),
        ("BACKGROUND",(2,1),(2,-1), colors.HexColor("#1A1408")),
        ("TEXTCOLOR",(0,1),(0,-1), GOLD_DIM),
        ("TEXTCOLOR",(2,1),(2,-1), GOLD_DIM),
        ("FONTNAME",(0,1),(0,-1),"Helvetica-Bold"),
        ("FONTNAME",(2,1),(2,-1),"Helvetica-Bold"),
        ("BACKGROUND",(1,1),(1,-1), DARK),
        ("BACKGROUND",(3,1),(3,-1), DARK),
        ("TEXTCOLOR",(1,1),(1,-1), TEXT),
        ("TEXTCOLOR",(3,1),(3,-1), TEXT),
        ("FONTNAME",(1,1),(-1,-1),"Helvetica"),
        ("FONTSIZE",(0,0),(-1,-1),9),
        ("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#2A2A2A")),
        ("ALIGN",(1,0),(-1,-1),"CENTER"),
        ("LEFTPADDING",(0,0),(-1,-1),7),
        ("TOPPADDING",(0,0),(-1,-1),4),
        ("BOTTOMPADDING",(0,0),(-1,-1),4),
    ]))
    story.append(met_tbl)
    story.append(Spacer(1, 6*mm))

    # Scores IA
    story.append(Paragraph("Scores & Diagnostics PHG IA", gold_h2))
    scores_data = [["Critère", "Score", "Appréciation"]]
    for k, v in SCORES.items():
        appr = "Excellent" if v >= 90 else "Bon" if v >= 80 else "Correct" if v >= 65 else "À améliorer"
        scores_data.append([k.replace("_", " "), f"{v} / 100", appr])
    sc_tbl = Table(scores_data, colWidths=[70*mm, 40*mm, 55*mm])
    sc_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1A1408")),
        ("TEXTCOLOR",(0,0),(-1,0),GOLD),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[DARK, PANEL]),
        ("TEXTCOLOR",(0,1),(-1,-1),TEXT),
        ("FONTNAME",(0,1),(-1,-1),"Helvetica"),
        ("FONTSIZE",(0,0),(-1,-1),9),
        ("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#2A2A2A")),
        ("ALIGN",(1,0),(2,-1),"CENTER"),
        ("LEFTPADDING",(0,0),(-1,-1),7),
        ("TOPPADDING",(0,0),(-1,-1),4),
        ("BOTTOMPADDING",(0,0),(-1,-1),4),
    ]))
    story.append(sc_tbl)
    story.append(Spacer(1, 6*mm))

    # Diagnostics
    story.append(Paragraph("Diagnostics & Recommandations IA", gold_h2))
    for iss in ISSUES:
        sev_col = OK if iss["sev"]=="OK" else WARN if iss["sev"]=="MOYEN" else GOLD
        sev_lbl = {"OK":"✓ OK","MOYEN":"⚠ Attention","INFO":"ℹ Info"}.get(iss["sev"],"")
        iss_data = [[f"{sev_lbl}", iss["titre"], f"→ {iss['sol']}"]]
        iss_tbl = Table(iss_data, colWidths=[22*mm, 65*mm, 78*mm])
        iss_tbl.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0), DARK),
            ("TEXTCOLOR",(0,0),(0,0), sev_col),
            ("TEXTCOLOR",(1,0),(1,0), TEXT),
            ("TEXTCOLOR",(2,0),(2,0), sev_col),
            ("FONTNAME",(0,0),(0,0),"Helvetica-Bold"),
            ("FONTNAME",(1,0),(-1,0),"Helvetica"),
            ("FONTSIZE",(0,0),(-1,0),8),
            ("GRID",(0,0),(-1,0),0.3,colors.HexColor("#2A2A2A")),
            ("LEFTPADDING",(0,0),(-1,0),6),
            ("TOPPADDING",(0,0),(-1,0),4),
            ("BOTTOMPADDING",(0,0),(-1,0),4),
            ("VALIGN",(0,0),(-1,0),"MIDDLE"),
        ]))
        story.append(iss_tbl)
        story.append(Spacer(1, 1*mm))
    story.append(PageBreak())

    # ── PAGE 4 : MATÉRIAUX ──────────────────────────────────────────────
    story.append(Paragraph("Liste complète des matériaux", gold_h1))
    story.append(HR())
    mat_data = [["Matériau", "Catégorie", "Qté", "Unité", "P.U.", "Total"]]
    for m in MATERIALS:
        mat_data.append([m["n"], m["cat"], fmt_n(m["q"]), m["u"],
                         f"{m['pu']:.2f} {CUR}", f"{fmt_n(m['t'])} {CUR}"])
    mat_data.append(["", "", "", "", "TOTAL MATÉRIAUX", f"{fmt_n(COSTS['materiaux'])} {CUR}"])

    mat_tbl = Table(mat_data, colWidths=[52*mm, 25*mm, 18*mm, 12*mm, 25*mm, 33*mm])
    mat_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1A1408")),
        ("TEXTCOLOR",(0,0),(-1,0),GOLD),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("BACKGROUND",(0,-1),(-1,-1),colors.HexColor("#1A1408")),
        ("TEXTCOLOR",(0,-1),(-1,-1),GOLD),
        ("FONTNAME",(0,-1),(-1,-1),"Helvetica-Bold"),
        ("ROWBACKGROUNDS",(0,1),(-1,-2),[DARK, PANEL]),
        ("TEXTCOLOR",(0,1),(-1,-2),TEXT),
        ("FONTNAME",(0,1),(-1,-2),"Helvetica"),
        ("FONTSIZE",(0,0),(-1,-1),8),
        ("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#2A2A2A")),
        ("ALIGN",(2,0),(-1,-1),"RIGHT"),
        ("LEFTPADDING",(0,0),(-1,-1),5),
        ("TOPPADDING",(0,0),(-1,-1),4),
        ("BOTTOMPADDING",(0,0),(-1,-1),4),
    ]))
    story.append(mat_tbl)
    story.append(Spacer(1, 6*mm))

    # ── PAGE 5 : ESTIMATION FINANCIÈRE ──────────────────────────────────
    story.append(Paragraph("Estimation financière détaillée", gold_h1))
    story.append(HR())

    fin_data = [
        ["Poste", "Montant", "% du total"],
        ["Matériaux", f"{fmt_n(COSTS['materiaux'])} {CUR}", f"{COSTS['materiaux']*100//COSTS['total']}%"],
        ["Main d'œuvre", f"{fmt_n(COSTS['main_oeuvre'])} {CUR}", f"{COSTS['main_oeuvre']*100//COSTS['total']}%"],
        ["Logistique (3%)", f"{fmt_n(COSTS['logistique'])} {CUR}", f"{COSTS['logistique']*100//COSTS['total']}%"],
        ["Marge risque (8%)", f"{fmt_n(COSTS['marge_risque'])} {CUR}", f"{COSTS['marge_risque']*100//COSTS['total']}%"],
    ]
    fin_tbl = Table(fin_data, colWidths=[80*mm, 60*mm, 25*mm])
    fin_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1A1408")),
        ("TEXTCOLOR",(0,0),(-1,0),GOLD),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[DARK, PANEL]),
        ("TEXTCOLOR",(0,1),(-1,-1),TEXT),
        ("FONTNAME",(0,1),(-1,-1),"Helvetica"),
        ("FONTSIZE",(0,0),(-1,-1),10),
        ("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#2A2A2A")),
        ("ALIGN",(1,0),(-1,-1),"RIGHT"),
        ("LEFTPADDING",(0,0),(-1,-1),8),
        ("TOPPADDING",(0,0),(-1,-1),6),
        ("BOTTOMPADDING",(0,0),(-1,-1),6),
    ]))
    story.append(fin_tbl)
    story.append(Spacer(1, 4*mm))

    # Total encadré
    total_data = [["TOTAL ESTIMÉ (TTC)", f"{fmt_n(COSTS['total'])} {CUR}"]]
    tot_tbl = Table(total_data, colWidths=[80*mm, 85*mm])
    tot_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),GOLD),
        ("TEXTCOLOR",(0,0),(-1,0),BLACK),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("FONTSIZE",(0,0),(-1,0),13),
        ("ALIGN",(1,0),(1,0),"RIGHT"),
        ("LEFTPADDING",(0,0),(-1,0),10),
        ("RIGHTPADDING",(0,0),(-1,0),10),
        ("TOPPADDING",(0,0),(-1,0),8),
        ("BOTTOMPADDING",(0,0),(-1,0),8),
        ("LINEBELOW",(0,0),(-1,0),2,GOLD_DIM),
    ]))
    story.append(tot_tbl)
    story.append(Spacer(1, 6*mm))

    # Comparaison 3 niveaux
    story.append(Paragraph("Comparaison Éco / Standard / Premium", gold_h2))
    comp_data = [
        ["Niveau", "Estimation", "Vs Standard", "Recommandation"],
        ["Économique (−20%)", f"{fmt_n(int(COSTS['total']*0.80))} {CUR}", "−20%", "Budget serré / locatif"],
        ["Standard (référence)", f"{fmt_n(COSTS['total'])} {CUR}", "Référence", "✓ Recommandé"],
        ["Premium (+32%)", f"{fmt_n(int(COSTS['total']*1.32))} {CUR}", "+32%", "Investissement long terme"],
    ]
    comp_tbl = Table(comp_data, colWidths=[50*mm, 45*mm, 25*mm, 45*mm])
    comp_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1A1408")),
        ("TEXTCOLOR",(0,0),(-1,0),GOLD),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("BACKGROUND",(0,1),(-1,1),colors.HexColor("#081A08")),
        ("BACKGROUND",(0,2),(-1,2),DARK),
        ("BACKGROUND",(0,3),(-1,3),colors.HexColor("#1A0808")),
        ("TEXTCOLOR",(0,1),(-1,1),OK),
        ("TEXTCOLOR",(0,2),(-1,2),GOLD),
        ("TEXTCOLOR",(0,3),(-1,3),ERR),
        ("FONTNAME",(0,1),(-1,-1),"Helvetica"),
        ("FONTSIZE",(0,0),(-1,-1),9),
        ("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#2A2A2A")),
        ("ALIGN",(1,0),(-1,-1),"CENTER"),
        ("LEFTPADDING",(0,0),(-1,-1),7),
        ("TOPPADDING",(0,0),(-1,-1),5),
        ("BOTTOMPADDING",(0,0),(-1,-1),5),
    ]))
    story.append(comp_tbl)
    story.append(Spacer(1, 6*mm))
    story.append(HR())
    story.append(Spacer(1, 3*mm))

    disclaimer = ("Ce rapport a été généré par PHG BUILD IA — instrument de référence pour architectes, géomètres et particuliers. "
                  "L'estimation est fournie à titre indicatif et ne constitue pas un devis contractuel. "
                  "Les prix sont basés sur les données de marché de la région sélectionnée à la date de génération. "
                  "PHG Éditions · Saint-Julien-en-Genevois · contact@phgeditions.com")
    story.append(Paragraph(disclaimer, sty("Normal", fontSize=7, textColor=DIM, leading=11)))

    doc.build(story, onFirstPage=page_template, onLaterPages=page_template)
    print(f"PDF généré : {output_path}")


# ═══════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    os.makedirs("/mnt/user-data/outputs", exist_ok=True)
    plan_png = "/home/claude/plan_phg.png"
    pdf_out  = "/mnt/user-data/outputs/PHG_BUILD_IA_Rapport_Complet.pdf"
    png_out  = "/mnt/user-data/outputs/PHG_Plan_2D.png"

    print("1/3 — Génération du plan PNG...")
    ok = generate_plan_png(plan_png)
    if ok:
        import shutil
        shutil.copy(plan_png, png_out)
        print(f"    Plan PNG : {png_out}")

    print("2/3 — Génération du PDF complet...")
    build_pdf(pdf_out, plan_png if ok else None)

    print("3/3 — Terminé ✓")
    print(f"\nFichiers exportés :")
    print(f"  PDF  : {pdf_out}")
    if ok: print(f"  PNG  : {png_out}")

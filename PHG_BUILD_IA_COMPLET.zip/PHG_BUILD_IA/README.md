# 𓂀 PHG BUILD IA — Guide d'installation avec Claude Code

**Auteur :** Goulia Frédéric Richard — PHG Éditions  
**Version :** 1.0 — Prêt pour Claude Code  

---

## 📁 Structure du projet

```
PHG_BUILD_IA/
├── frontend/
│   ├── App.jsx              ← App principale React (plan, métrés, devis, VR)
│   └── Dashboard.jsx        ← Dashboard avec sidebar PHG
├── backend/
│   ├── phg_export.py        ← Générateur PDF + PNG (ReportLab)
│   ├── requirements.txt     ← Dépendances Python
│   └── .env.example         ← Template variables d'environnement
└── exports/
    ├── PHG_BUILD_IA_Rapport_Complet.pdf
    ├── PHG_Plan_2D.png
    └── PHG_BUILD_IA_Guide_Deploiement.docx
```

---

## 🚀 Installation avec Claude Code

### Étape 1 — Installer Claude Code

**Mac / Linux :**
```bash
curl -fsSL https://claude.ai/install.sh | bash
source ~/.bashrc  # ou source ~/.zshrc
claude --version
```

**Windows (PowerShell) :**
```powershell
irm https://claude.ai/install.ps1 | iex
```

### Étape 2 — Ouvrir Claude Code dans ce dossier

```bash
cd PHG_BUILD_IA
claude
```

### Étape 3 — Donner ces instructions à Claude Code

Copiez-collez ce message dans Claude Code :

```
Tu travailles sur PHG BUILD IA — une plateforme de construction intelligente.

Les fichiers existants sont :
- frontend/App.jsx : l'application React complète avec plan 2D, métrés, devis, VR
- backend/phg_export.py : le générateur PDF/PNG

Voici ce que tu dois faire :
1. Créer le backend FastAPI complet (phg_build_ia_backend.py) avec :
   - Modèles SQLAlchemy : Country, Client, Project, Subscription, Material, Price
   - Endpoints : POST /projects, GET /projects, POST /projects/{id}/estimate
   - Endpoint POST /create-checkout pour Stripe
   - Webhook Stripe POST /webhook
   - Auth JWT : POST /auth/register, POST /auth/login
   - Seed automatique : 9 pays, 45 matériaux avec prix locaux

2. Connecter le frontend App.jsx aux vrais endpoints (remplacer les calculs locaux)

3. Configurer les variables d'environnement depuis .env.example

4. Créer les tests de paiement Stripe en mode sandbox

Commence par le backend FastAPI.
```

---

## ⚡ Démarrage rapide (sans Claude Code)

### Backend
```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Remplir les valeurs dans .env
uvicorn phg_build_ia_backend:app --reload --port 8000
```

### Frontend
```bash
npm create vite@latest phg-frontend -- --template react
cd phg-frontend
cp ../frontend/App.jsx src/App.jsx
npm install
npm run dev
```

### Export PDF/PNG
```bash
cd backend
pip install reportlab pillow
python phg_export.py
```

---

## ✅ Ce qui est déjà fait (70%)

| Module | Statut |
|--------|--------|
| Plan 2D interactif avec cotes | ✅ 100% |
| Architecte IA + Géomètre IA | ✅ 100% |
| 45 pays avec prix locaux | ✅ 100% |
| Calcul métrés + devis 4 phases | ✅ 100% |
| Vue holographique 3D | ✅ 100% |
| Visite immersive VR | ✅ 100% |
| Export PDF + PNG | ✅ 100% |
| Anti-arnaque + Guide chantier | ✅ 100% |
| Planning construction | ✅ 100% |
| Simulateur paiement Stripe (test) | ✅ 100% |
| Backend FastAPI (local) | ✅ 85% |

## 🔧 Ce qui reste (30%)

| Tâche | Durée estimée |
|-------|---------------|
| Auth JWT utilisateurs | 2 jours |
| Stripe live (3 plans) | 1 jour |
| CinetPay Mobile Money | 2 jours |
| Sauvegarde projets PostgreSQL | 2 jours |
| Tests end-to-end | 2 jours |
| Déploiement Railway + Vercel | 1 jour |
| CGU + RGPD | 1 jour |

---

## 💰 Plans tarifaires

| Plan | Prix Europe | Prix Afrique | Public |
|------|-------------|--------------|--------|
| Gratuit | 0€ | 0€ | Découverte |
| PRO | 5€/mois | 5€/mois | Architectes, particuliers |
| ELITE | 20€/mois | 10€/mois | Cabinets, bureaux études |

---

## 🌍 Pays couverts (45)

Afrique francophone (CI, SN, ML, CM, BF, TG, BJ, GN, MG, RDC...)  
Afrique anglophone (GH, NG, KE, ET, ZA, TZ...)  
Maghreb (MA, DZ, TN)  
Europe (FR, CH, BE, DE, PT, ES, IT, NL, GB...)  
Amériques (CA, US, BR, MX, HT, GP, RE)  
Asie/Moyen-Orient (VN, IN, AE, TR, LB)  

---

## 📞 Contact PHG Éditions

**Goulia Frédéric Richard**  
PHG Éditions — Saint-Julien-en-Genevois  
Marque : PHARAOH GOLD PHG ÉDITIONS  

---

*PHG BUILD IA — L'instrument de référence · Construction mondiale*  
*𓂀 Architecte IA · Géomètre IA · Particulier protégé*

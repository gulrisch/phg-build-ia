import { useState, useCallback } from "react";

// ── PHG BUILD IA — App complète avec plans Gratuit / Pro 5€ / Elite 20€ (Afrique 10€)
// Connecter à l'API : remplacer la constante API par votre URL backend
const API = "http://localhost:8000";

const PRICES = {
  FR:{beton:185,acier:1.4,par:1.8,cim:8.5,sable:42,grav:48,tole:18,tuile:28,tuile_pre:42,fen:280,cable:2.8,pvc:3.4,maçon:220,elec:250,plom:260,ing:420},
  CH:{beton:260,acier:1.95,par:3.4,cim:12.5,sable:68,grav:75,tole:0,tuile:42,tuile_pre:56,fen:420,cable:4.2,pvc:4.9,maçon:380,elec:420,plom:440,ing:650},
  CI:{beton:120,acier:1.05,par:0.95,cim:5.2,sable:24,grav:27,tole:11,tuile:18,tuile_pre:26,fen:145,cable:1.1,pvc:1.4,maçon:40,elec:55,plom:50,ing:120},
  SN:{beton:115,acier:1.1,par:0.9,cim:5,sable:22,grav:25,tole:10,tuile:17,tuile_pre:24,fen:130,cable:1.0,pvc:1.3,maçon:35,elec:48,plom:45,ing:100},
  MA:{beton:130,acier:1.2,par:1.1,cim:6,sable:28,grav:32,tole:13,tuile:20,tuile_pre:30,fen:190,cable:1.4,pvc:1.7,maçon:55,elec:70,plom:65,ing:140},
  CA:{beton:200,acier:1.6,par:2.1,cim:10,sable:50,grav:55,tole:22,tuile:34,tuile_pre:50,fen:350,cable:3.2,pvc:4.0,maçon:280,elec:320,plom:330,ing:500},
};
const CUR = {FR:"€",CH:"CHF",CI:"FCFA",SN:"FCFA",MA:"MAD",CA:"CAD"};
const COUNTRIES = [
  {code:"FR",flag:"🇫🇷",name:"France",cur:"EUR"},
  {code:"CH",flag:"🇨🇭",name:"Suisse",cur:"CHF"},
  {code:"CI",flag:"🇨🇮",name:"Côte d'Ivoire",cur:"XOF"},
  {code:"SN",flag:"🇸🇳",name:"Sénégal",cur:"XOF"},
  {code:"MA",flag:"🇲🇦",name:"Maroc",cur:"MAD"},
  {code:"CA",flag:"🇨🇦",name:"Canada",cur:"CAD"},
];

const css = `
@import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Montserrat:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
:root{
  --gold:#C9A84C;--gold2:#E8CC7A;--gold3:#7A6330;
  --bg:#0A0A0A;--panel:#141414;--panel2:#1C1C1C;--panel3:#222;
  --border:#272727;--border2:#333;
  --text:#EAE2D0;--dim:#808078;--dim2:#505048;
  --ok:#4CAF6E;--warn:#E8A94C;--err:#C94C4C;
  --r:7px;--r2:12px;
}
body{background:var(--bg);color:var(--text);font-family:'Montserrat',sans-serif;font-size:13px}
.app{display:flex;min-height:100vh}
.sb{width:224px;min-height:100vh;background:var(--panel);border-right:1px solid var(--border);display:flex;flex-direction:column;flex-shrink:0;position:sticky;top:0;height:100vh}
.sb-top{padding:20px 18px 14px;border-bottom:1px solid var(--border);text-align:center}
.sb-glyph{font-size:28px;color:var(--gold);line-height:1}
.sb-brand{font-family:'Cinzel',serif;font-size:14px;color:var(--gold);letter-spacing:2px;margin:5px 0 2px}
.sb-sub{font-size:9px;color:var(--dim);letter-spacing:2.5px}
.plan-badge{display:inline-block;margin-top:7px;padding:2px 10px;border-radius:20px;font-size:9px;font-weight:600;letter-spacing:1px}
.pf{background:rgba(136,136,120,.15);color:var(--dim)}
.pp{background:rgba(201,168,76,.15);color:var(--gold)}
.pe{background:rgba(201,76,76,.12);color:#D4857A}
.sb-nav{flex:1;padding:8px 0;overflow-y:auto}
.nav-sec{padding:10px 16px 3px;font-size:9px;color:var(--gold3);letter-spacing:3px;text-transform:uppercase}
.nav-item{display:flex;align-items:center;gap:8px;padding:8px 16px;color:var(--dim);cursor:pointer;font-size:12px;font-weight:500;transition:all .15s;border-left:2px solid transparent}
.nav-item:hover{color:var(--text);background:rgba(201,168,76,.05)}
.nav-item.active{color:var(--gold);background:rgba(201,168,76,.09);border-left-color:var(--gold)}
.nav-lock{font-size:10px;margin-left:auto;opacity:.5}
.sb-foot{padding:12px 16px;border-top:1px solid var(--border);font-size:10px;color:var(--dim2);line-height:1.6}
.main{flex:1;display:flex;flex-direction:column;min-width:0}
.topbar{background:var(--panel);border-bottom:1px solid var(--border);padding:0 24px;height:52px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:10}
.tb-title{font-family:'Cinzel',serif;font-size:13px;color:var(--gold);letter-spacing:1.5px}
.tb-btns{display:flex;gap:7px}
.btn{padding:6px 14px;border-radius:var(--r);font-size:11px;font-family:'Montserrat',sans-serif;font-weight:600;letter-spacing:.4px;cursor:pointer;border:none;transition:all .15s;display:inline-flex;align-items:center;gap:5px}
.btn-gold{background:var(--gold);color:#0A0A0A}
.btn-gold:hover{background:var(--gold2)}
.btn-out{background:transparent;border:1px solid var(--border2);color:var(--dim)}
.btn-out:hover{border-color:var(--gold);color:var(--gold)}
.btn-sm{padding:5px 11px;font-size:10px}
.btn-block{width:100%;justify-content:center}
.content{padding:20px;flex:1;overflow-y:auto}
.card{background:var(--panel);border:1px solid var(--border);border-radius:var(--r2);padding:16px;margin-bottom:12px}
.card-title{font-family:'Cinzel',serif;font-size:10px;color:var(--gold);letter-spacing:2px;margin-bottom:12px;text-transform:uppercase}
.kpi-row{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px}
.kpi{background:var(--panel);border:1px solid var(--border);border-top:2px solid var(--gold);border-radius:var(--r);padding:12px 14px}
.kpi-lbl{font-size:9px;color:var(--dim);text-transform:uppercase;letter-spacing:2px;margin-bottom:4px}
.kpi-val{font-family:'Cinzel',serif;font-size:20px;color:var(--gold)}
.kpi-sub{font-size:10px;color:var(--dim);margin-top:2px}
.plan-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:18px}
.plan-card{background:var(--panel);border:1px solid var(--border);border-radius:var(--r2);padding:18px;text-align:center;position:relative;transition:all .2s}
.plan-card:hover{transform:translateY(-2px)}
.plan-card.featured{border-color:var(--gold)}
.plan-chip{position:absolute;top:-10px;left:50%;transform:translateX(-50%);background:var(--gold);color:#0A0A0A;font-size:9px;font-weight:700;letter-spacing:1.5px;padding:2px 10px;border-radius:20px;white-space:nowrap}
.plan-icon{font-size:26px;margin-bottom:6px}
.plan-name{font-family:'Cinzel',serif;font-size:13px;margin-bottom:5px}
.plan-amount{font-family:'Cinzel',serif;font-size:26px;color:var(--gold)}
.plan-period{font-size:10px;color:var(--dim)}
.plan-africa{font-size:10px;color:var(--ok);margin:3px 0 10px;min-height:14px}
.plan-feats{list-style:none;font-size:11px;color:var(--dim);text-align:left;margin-bottom:12px}
.plan-feats li{padding:3px 0;border-bottom:1px solid var(--border);display:flex;gap:5px;align-items:center}
.plan-feats li:last-child{border:none}
.fok{color:var(--ok)}.fno{color:var(--dim2)}
.steps{display:flex;margin-bottom:18px}
.step{flex:1;text-align:center;padding:8px 2px;font-size:10px;color:var(--dim);border-bottom:2px solid var(--border);transition:all .15s}
.step.done{color:var(--gold);border-bottom-color:var(--gold)}
.step-n{display:inline-block;width:16px;height:16px;border-radius:50%;border:1px solid currentColor;line-height:16px;font-size:9px;margin-bottom:2px}
.fg2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.fg3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}
.fg{display:flex;flex-direction:column;gap:4px;margin-bottom:8px}
label{font-size:10px;color:var(--dim);text-transform:uppercase;letter-spacing:1px}
input,select,textarea{background:var(--panel2);border:1px solid var(--border2);border-radius:var(--r);color:var(--text);padding:7px 10px;font-family:'Montserrat',sans-serif;font-size:12px;outline:none;transition:border .15s;width:100%}
input:focus,select:focus,textarea:focus{border-color:var(--gold)}
select option{background:var(--panel2)}
textarea{resize:vertical;min-height:60px}
.cnt-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-bottom:12px}
.cnt{background:var(--panel2);border:1px solid var(--border);border-radius:var(--r);padding:9px;cursor:pointer;text-align:center;transition:all .15s}
.cnt:hover,.cnt.sel{border-color:var(--gold);background:rgba(201,168,76,.07)}
.cnt-flag{font-size:20px;margin-bottom:2px}
.cnt-name{font-size:11px;font-weight:500}
.cnt-cur{font-size:9px;color:var(--dim)}
.q-row{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}
.q-card{border:1px solid var(--border2);border-radius:var(--r);padding:12px;cursor:pointer;transition:all .15s;text-align:center}
.q-card.sel{border-color:var(--gold);background:rgba(201,168,76,.07)}
.q-name{font-size:12px;font-weight:600;margin-bottom:2px}
.q-sub{font-size:10px;color:var(--dim);line-height:1.5}
.q-delta{font-size:11px;font-weight:600;margin-top:5px}
.tabs{display:flex;border-bottom:1px solid var(--border);margin-bottom:16px}
.tab{padding:8px 16px;font-size:11px;font-weight:600;letter-spacing:.4px;color:var(--dim);cursor:pointer;border-bottom:2px solid transparent;transition:all .15s;text-transform:uppercase}
.tab.active{color:var(--gold);border-bottom-color:var(--gold)}
.result-wrap{background:var(--panel2);border:1px solid var(--gold3);border-radius:var(--r);padding:16px}
.cost-line{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px}
.cost-line:last-child{border:none}
.cost-line.total{font-weight:600;color:var(--gold);font-size:14px;margin-top:6px;padding-top:8px;border-top:1px solid var(--gold3)}
.cost-lbl{color:var(--dim)}
.mat-tbl{width:100%;border-collapse:collapse;font-size:11px;margin-bottom:10px}
.mat-tbl th{text-align:left;padding:5px 8px;font-size:9px;color:var(--dim);text-transform:uppercase;letter-spacing:1px;border-bottom:1px solid var(--border)}
.mat-tbl td{padding:6px 8px;border-bottom:1px solid rgba(255,255,255,.03)}
.badge{display:inline-block;padding:2px 7px;border-radius:20px;font-size:9px;font-weight:700;letter-spacing:.5px;text-transform:uppercase}
.b-house{background:rgba(201,168,76,.12);color:var(--gold)}.b-bridge{background:rgba(122,168,201,.12);color:#7AABC9}
.b-draft{background:rgba(136,136,120,.12);color:var(--dim)}.b-est{background:rgba(201,168,76,.15);color:var(--gold)}
.b-eco{background:rgba(76,175,110,.12);color:var(--ok)}.b-std{background:rgba(201,168,76,.12);color:var(--gold)}.b-pre{background:rgba(201,76,76,.12);color:#D4857A}
.lock-overlay{background:rgba(10,10,10,.85);border:1px solid var(--gold3);border-radius:var(--r2);padding:22px;text-align:center;margin-top:12px}
.lock-icon{font-size:26px;color:var(--gold);margin-bottom:6px}
.lock-title{font-family:'Cinzel',serif;font-size:13px;color:var(--gold);margin-bottom:5px}
.lock-sub{font-size:11px;color:var(--dim);margin-bottom:12px;line-height:1.7}
.score-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-bottom:10px}
.sc-item{background:var(--panel2);border:1px solid var(--border);border-radius:var(--r);padding:9px;text-align:center}
.sc-num{font-family:'Cinzel',serif;font-size:20px}
.sc-lbl{font-size:9px;color:var(--dim);text-transform:uppercase;letter-spacing:.5px;margin-top:2px}
.rec-item{background:var(--panel2);border:1px solid var(--border);border-radius:var(--r);padding:10px;margin-bottom:7px}
.rec-hdr{display:flex;justify-content:space-between;margin-bottom:4px}
.rec-ttl{font-size:12px;font-weight:600}
.sev-h{font-size:10px;font-weight:700;color:var(--err)}.sev-m{font-size:10px;font-weight:700;color:var(--warn)}.sev-l{font-size:10px;font-weight:700;color:var(--ok)}
.rec-body{font-size:11px;color:var(--dim);line-height:1.7}
.gain{display:inline-block;background:rgba(76,175,110,.1);color:var(--ok);border-radius:4px;padding:2px 7px;font-size:10px;margin-top:3px}
.inf-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}
.inf-card{background:var(--panel2);border:1px solid var(--border);border-radius:var(--r);padding:12px;cursor:pointer;text-align:center;transition:all .15s}
.inf-card:hover,.inf-card.sel{border-color:var(--gold);background:rgba(201,168,76,.07)}
.upload-z{border:2px dashed var(--border2);border-radius:var(--r);padding:24px;text-align:center;cursor:pointer;transition:all .2s;margin-bottom:10px}
.upload-z:hover{border-color:var(--gold);background:rgba(201,168,76,.03)}
.main-tbl{width:100%;border-collapse:collapse;font-size:12px}
.main-tbl th{text-align:left;padding:7px 10px;font-size:9px;color:var(--dim);text-transform:uppercase;letter-spacing:1px;border-bottom:1px solid var(--border)}
.main-tbl td{padding:9px 10px;border-bottom:1px solid rgba(255,255,255,.03)}
.spinner{width:24px;height:24px;border:2px solid var(--border2);border-top-color:var(--gold);border-radius:50%;animation:spin .7s linear infinite;margin:20px auto}
@keyframes spin{to{transform:rotate(360deg)}}
.alert{padding:8px 12px;border-radius:var(--r);font-size:11px;margin-top:8px;line-height:1.6}
.alert-ok{background:rgba(76,175,110,.08);border:1px solid rgba(76,175,110,.25);color:var(--ok)}
.alert-warn{background:rgba(232,169,76,.08);border:1px solid rgba(232,169,76,.25);color:var(--warn)}
.note{background:rgba(201,168,76,.05);border-left:3px solid var(--gold3);padding:8px 11px;font-size:11px;color:var(--dim);margin-top:8px;line-height:1.7}
.divgold{height:1px;background:linear-gradient(90deg,transparent,var(--gold3),transparent);margin:12px 0}
`;

const fmt = (n, d = 0) => Number(n).toLocaleString("fr-FR", { maximumFractionDigits: d });
const scColor = n => n >= 80 ? "var(--ok)" : n >= 60 ? "var(--warn)" : "var(--err)";

// ── Plan limits ──
const CAN = {
  infra: p => p !== "free",
  analyse: p => p !== "free",
  fullMaterials: p => p !== "free",
  recs: p => p !== "free",
  pdf: p => p !== "free",
  unlimitedProjects: p => p !== "free",
};

export default function App() {
  const [page, setPage] = useState("accueil");
  const [plan, setPlan] = useState("free");

  // Maison state
  const [step, setStep] = useState(1);
  const [cc, setCc] = useState("FR");
  const [mForm, setMForm] = useState({ l: 12, w: 10, fl: 1, roofType: "pitched", budget: "", sdb: 2, desc: "Maison 120m², 3 chambres, salon, cuisine ouverte" });
  const [qual, setQual] = useState("std");
  const [computing, setComputing] = useState(false);
  const [mResult, setMResult] = useState(null);
  const [mTab, setMTab] = useState("mat");

  // Infra state
  const [infType, setInfType] = useState("pont");
  const [iForm, setIForm] = useState({ l: 50, w: 8, type: "beton", piers: 2, pHeight: 4, country: "CI" });
  const [iComputing, setIComputing] = useState(false);
  const [iResult, setIResult] = useState(null);
  const [iTab, setITab] = useState("mat");

  // Analyse state
  const [uploaded, setUploaded] = useState(false);
  const [anCC, setAnCC] = useState("CI");
  const [anComputing, setAnComputing] = useState(false);
  const [anResult, setAnResult] = useState(null);

  // Projects
  const [projects] = useState([
    { id: 1, name: "Villa Cocody", type: "house", country: "🇨🇮", qual: "pre", cost: 48200, status: "estimated" },
    { id: 2, name: "Pont rural Man", type: "bridge", country: "🇨🇮", qual: "eco", cost: 112000, status: "estimated" },
    { id: 3, name: "Maison Lyon", type: "house", country: "🇫🇷", qual: "std", cost: null, status: "draft" },
  ]);

  const activatePlan = (p) => {
    setPlan(p);
    const labels = { free: "Gratuit", pro: "PRO — 5 €/mois", elite: "ELITE — 20 €/mois", "elite-africa": "ELITE AFRIQUE — 10 €/mois" };
    alert(`✓ Plan activé : ${labels[p]}\n\n(Dans l'app réelle, le paiement Stripe s'ouvre ici.)`);
  };

  const computeMaison = useCallback(() => {
    const { l, w, fl, budget } = mForm;
    const P = PRICES[cc] || PRICES.FR;
    const C = CUR[cc] || "€";
    const qm = qual === "eco" ? 0.80 : qual === "pre" ? 1.32 : 1.0;
    const surf = l * w * fl;
    const wallS = 2 * (l + w) * 3.0 * fl;
    const roofS = l * w * 1.15;
    const roofKey = qual === "eco" ? "tole" : qual === "pre" ? "tuile_pre" : "tuile";
    const roofName = qual === "eco" ? "Tôle bac acier" : qual === "pre" ? "Tuile terre cuite premium" : "Tuile béton";
    const blockQ = Math.round(wallS / 0.08 * 1.05);
    const cimQ = Math.round(surf * 0.15 * 350 / 35 * 1.03);
    const sandV = parseFloat((surf * 0.15 * 0.5).toFixed(1));
    const gravV = parseFloat((surf * 0.15 * 0.8).toFixed(1));
    const roofQ = Math.round(roofS * 1.08);
    const winN = Math.max(6, Math.round(surf / 18));
    const cableM = Math.round(surf * 6);
    const pvcM = Math.round(surf * 1.8);
    const materials = [
      { n: "Parpaing creux 20", q: blockQ, u: "pce", pu: P.par * qm, t: Math.round(blockQ * P.par * qm) },
      { n: "Ciment Portland 35kg", q: cimQ, u: "sac", pu: P.cim * qm, t: Math.round(cimQ * P.cim * qm) },
      { n: "Sable de construction", q: sandV, u: "m³", pu: P.sable * qm, t: Math.round(sandV * P.sable * qm) },
      { n: "Gravier", q: gravV, u: "m³", pu: P.grav * qm, t: Math.round(gravV * P.grav * qm) },
      { n: roofName, q: roofQ, u: "m²", pu: (P[roofKey] || P.tuile) * qm, t: Math.round(roofQ * (P[roofKey] || P.tuile) * qm) },
      { n: "Fenêtre aluminium", q: winN, u: "pce", pu: P.fen * qm, t: Math.round(winN * P.fen * qm) },
      { n: "Câble électrique", q: cableM, u: "m", pu: P.cable * qm, t: Math.round(cableM * P.cable * qm) },
      { n: "Tube PVC plomberie", q: pvcM, u: "m", pu: P.pvc * qm, t: Math.round(pvcM * P.pvc * qm) },
    ];
    const matCost = materials.reduce((s, m) => s + m.t, 0);
    const labCost = Math.round(Math.max(10, surf / 8) * P.maçon + Math.max(4, surf / 25) * P.elec + Math.max(3, surf / 30) * P.plom);
    const logCost = Math.round(matCost * 0.03);
    const sub = matCost + labCost + logCost;
    const risk = Math.round(sub * 0.08);
    const total = sub + risk;
    const budgetN = parseFloat(budget) || 0;
    const bs = budgetN > 0 ? (total <= budgetN ? 92 : 62) : 70;
    const gs = Math.round((bs + 88 + (qual === "pre" ? 94 : qual === "eco" ? 77 : 85) + 80) / 4);
    setMResult({ materials, matCost, labCost, logCost, risk, total, cur: C, budget: budgetN, surf, gs, bs });
  }, [cc, mForm, qual]);

  const launchMaison = () => {
    setStep(4);
    setMResult(null);
    setComputing(true);
    setMTab("mat");
    setTimeout(() => { setComputing(false); computeMaison(); }, 1700);
  };

  const computeInfra = () => {
    const { l, w, piers, pHeight, country } = iForm;
    const P = PRICES[country] || PRICES.CI;
    const C = CUR[country] || "€";
    const dV = l * w * 0.30, piV = piers * 1.0 * pHeight, abV = dV * 0.20;
    const totB = Math.round((dV + piV + abV) * 10) / 10;
    const steel = Math.round(totB * (l > 80 ? 140 : 110) * 1.04);
    const betonC = Math.round(totB * P.beton);
    const acierC = Math.round(steel * P.acier);
    const labC = Math.round(Math.max(20, totB / 3) * P.maçon + Math.max(5, l / 10) * P.ing);
    const logC = Math.round((betonC + acierC) * 0.06);
    const sub = betonC + acierC + labC + logC;
    const risk = Math.round(sub * 0.15);
    const total = sub + risk;
    setIResult({ materials: [
      { n: "Béton armé (tablier)", q: (Math.round(dV * 10) / 10).toFixed(1), u: "m³", pu: fmt(P.beton), t: Math.round(dV * P.beton) },
      { n: "Béton armé (piles)", q: (Math.round(piV * 10) / 10).toFixed(1), u: "m³", pu: fmt(P.beton), t: Math.round(piV * P.beton) },
      { n: "Béton armé (culées)", q: (Math.round(abV * 10) / 10).toFixed(1), u: "m³", pu: fmt(P.beton), t: Math.round(abV * P.beton) },
      { n: "Acier armature HA", q: fmt(steel), u: "kg", pu: fmt(P.acier, 2), t: acierC },
    ], betonC, acierC, labC, logC, risk, total, cur: C });
  };

  const launchInfra = () => {
    setIResult(null);
    setIComputing(true);
    setITab("mat");
    setTimeout(() => { setIComputing(false); computeInfra(); }, 1600);
  };

  const launchAnalyse = () => {
    setAnResult(null);
    setAnComputing(true);
    setTimeout(() => {
      const P = PRICES[anCC] || PRICES.CI;
      const C = CUR[anCC] || "€";
      const surf = 100 + Math.round(Math.random() * 40);
      const base = surf * P.par * 80 + surf * P.cim * 12;
      setAnComputing(false);
      setAnResult({ surf, rooms: 5 + Math.round(Math.random() * 3), openings: 8 + Math.round(Math.random() * 4), eco: Math.round(base * 0.80), std: Math.round(base), pre: Math.round(base * 1.35), cur: C });
    }, 2200);
  };

  const pdfClick = () => {
    if (!CAN.pdf(plan)) alert("🔒 Export PDF réservé au plan PRO (5€/mois).\n\nLe PDF comprend : plan détaillé, liste complète des matériaux, estimation, notes de chantier — avec logo PHG.");
    else alert("✓ Génération du PDF en cours…\n\n(Dans l'app réelle, ReportLab génère le PDF côté serveur et le fichier est téléchargé automatiquement.)");
  };

  const planLabel = { free: "GRATUIT", pro: "PRO", elite: "ELITE", "elite-africa": "ELITE AFRIQUE" };
  const planBadgeClass = { free: "pf", pro: "pp", elite: "pe", "elite-africa": "pe" };

  const NAV = [
    { sec: "Démarrer" },
    { id: "accueil", icon: "◈", label: "Accueil & Tarifs" },
    { sec: "Conception" },
    { id: "maison", icon: "🏠", label: "Construire maison" },
    { id: "infra", icon: "🌉", label: "Infrastructure", lock: !CAN.infra(plan) },
    { id: "analyse", icon: "📐", label: "Analyser un plan", lock: !CAN.analyse(plan) },
    { sec: "Mes données" },
    { id: "projets", icon: "⬡", label: "Mes projets" },
    { id: "abonnement", icon: "◆", label: "Abonnement" },
  ];

  const titles = { accueil: "Accueil & Tarifs", maison: "Construire une maison", infra: "Infrastructure & Ponts", analyse: "Analyser un plan", projets: "Mes projets", abonnement: "Abonnement PHG" };

  return (
    <>
      <style>{css}</style>
      <div className="app">

        {/* ── SIDEBAR ── */}
        <aside className="sb">
          <div className="sb-top">
            <div className="sb-glyph">𓂀</div>
            <div className="sb-brand">PHG BUILD IA</div>
            <div className="sb-sub">Construction intelligente</div>
            <span className={`plan-badge ${planBadgeClass[plan]}`}>{planLabel[plan]}</span>
          </div>
          <nav className="sb-nav">
            {NAV.map((item, i) =>
              item.sec ? <div key={i} className="nav-sec">{item.sec}</div> : (
                <div key={item.id} className={`nav-item${page === item.id ? " active" : ""}`} onClick={() => setPage(item.id)}>
                  <span style={{ fontSize: 14 }}>{item.icon}</span>
                  {item.label}
                  {item.lock && <span className="nav-lock">🔒</span>}
                </div>
              )
            )}
          </nav>
          <div className="sb-foot">PHG Éditions<br />Saint-Julien-en-Genevois<br />© 2025</div>
        </aside>

        {/* ── MAIN ── */}
        <div className="main">
          <div className="topbar">
            <div className="tb-title">{titles[page] || "PHG BUILD IA"}</div>
            <div className="tb-btns">
              <button className="btn btn-out btn-sm" onClick={() => setPage("analyse")}>📤 Analyser plan</button>
              <button className="btn btn-gold btn-sm" onClick={() => { setPage("maison"); setStep(1); setMResult(null); }}>+ Nouveau projet</button>
            </div>
          </div>
          <div className="content">

            {/* ══ ACCUEIL ══ */}
            {page === "accueil" && (
              <div>
                <div style={{ textAlign: "center", padding: "32px 16px 24px", borderBottom: "1px solid var(--border)", marginBottom: 20 }}>
                  <div style={{ fontSize: 48, color: "var(--gold)", lineHeight: 1, marginBottom: 8 }}>𓂀</div>
                  <div style={{ fontFamily: "'Cinzel',serif", fontSize: 22, color: "var(--gold)", letterSpacing: 3, marginBottom: 5 }}>PHG BUILD IA</div>
                  <div style={{ fontSize: 12, color: "var(--dim)", marginBottom: 12 }}>Architecte IA · Géomètre · Économiste de la construction</div>
                  <div style={{ fontSize: 11, color: "var(--dim2)", maxWidth: 460, margin: "0 auto", lineHeight: 1.8 }}>Décrivez votre projet. L'IA génère le plan, calcule chaque matériau, estime le budget et prépare votre chantier — pour particuliers et professionnels, partout dans le monde.</div>
                </div>

                <div className="plan-grid">
                  {/* GRATUIT */}
                  <div className="plan-card">
                    <div className="plan-icon">🏗</div>
                    <div className="plan-name">Gratuit</div>
                    <div><span className="plan-amount">0</span><span className="plan-period"> €/mois</span></div>
                    <div className="plan-africa"></div>
                    <ul className="plan-feats">
                      <li><span className="fok">✓</span>1 projet actif</li>
                      <li><span className="fok">✓</span>Estimation globale</li>
                      <li><span className="fok">✓</span>3 matériaux aperçu</li>
                      <li><span className="fno">✗</span>Détail quantités</li>
                      <li><span className="fno">✗</span>Export PDF</li>
                      <li><span className="fno">✗</span>Infrastructure</li>
                    </ul>
                    <button className="btn btn-out btn-sm btn-block" onClick={() => activatePlan("free")}>Plan actuel</button>
                  </div>

                  {/* PRO */}
                  <div className="plan-card featured">
                    <div className="plan-chip">RECOMMANDÉ</div>
                    <div className="plan-icon">🏆</div>
                    <div className="plan-name">Pro</div>
                    <div><span className="plan-amount">5</span><span className="plan-period"> €/mois</span></div>
                    <div className="plan-africa">🌍 5 €/mois partout dans le monde</div>
                    <ul className="plan-feats">
                      <li><span className="fok">✓</span>Projets illimités</li>
                      <li><span className="fok">✓</span>Matériaux détaillés</li>
                      <li><span className="fok">✓</span>Recommandations IA</li>
                      <li><span className="fok">✓</span>Export PDF PHG</li>
                      <li><span className="fok">✓</span>Ponts + Infrastructure</li>
                      <li><span className="fok">✓</span>Analyse de plan uploadé</li>
                    </ul>
                    <button className="btn btn-gold btn-sm btn-block" onClick={() => activatePlan("pro")}>Activer PRO — 5 €/mois</button>
                  </div>

                  {/* ELITE */}
                  <div className="plan-card">
                    <div className="plan-icon">👑</div>
                    <div className="plan-name">Elite</div>
                    <div><span className="plan-amount">20</span><span className="plan-period"> €/mois</span></div>
                    <div className="plan-africa">🌍 Afrique : <strong style={{ color: "var(--ok)" }}>10 €/mois</strong></div>
                    <ul className="plan-feats">
                      <li><span className="fok">✓</span>Tout du plan Pro</li>
                      <li><span className="fok">✓</span>Multi-clients / devis</li>
                      <li><span className="fok">✓</span>Marque blanche PDF</li>
                      <li><span className="fok">✓</span>Export BIM / DXF</li>
                      <li><span className="fok">✓</span>API privée PHG</li>
                      <li><span className="fok">✓</span>Support prioritaire 24h</li>
                    </ul>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button className="btn btn-out btn-sm" style={{ flex: 1 }} onClick={() => activatePlan("elite")}>Europe 20€</button>
                      <button className="btn btn-gold btn-sm" style={{ flex: 1 }} onClick={() => activatePlan("elite-africa")}>Afrique 10€</button>
                    </div>
                  </div>
                </div>

                <div className="card">
                  <div className="card-title">Comparaison des fonctionnalités</div>
                  <table className="main-tbl">
                    <thead><tr><th>Fonctionnalité</th><th>Gratuit</th><th>Pro 5€</th><th>Elite 20€ / 10€</th></tr></thead>
                    <tbody>
                      {[
                        ["Projets actifs", "1", "Illimité", "Illimité"],
                        ["Estimation de coût", "Globale", "Détaillée", "Détaillée"],
                        ["Liste matériaux", "3 aperçu", "Complète + quantités", "Complète + quantités"],
                        ["Ponts & infrastructures", "✗", "✓", "✓"],
                        ["Analyse de plan uploadé", "✗", "✓", "✓"],
                        ["Export PDF professionnel", "✗", "✓ logo PHG", "✓ marque blanche"],
                        ["Multi-clients / devis", "✗", "✗", "✓"],
                        ["API privée + BIM/DXF", "✗", "✗", "✓"],
                        ["Pays couverts", "3", "6+", "Monde entier"],
                        ["Support", "Communauté", "Email 48h", "Prioritaire 24h"],
                      ].map(([f, a, b, c], i) => (
                        <tr key={i}>
                          <td>{f}</td>
                          <td style={{ color: a === "✗" ? "var(--err)" : a.includes("✓") || a === "Illimité" ? "var(--ok)" : "var(--dim)" }}>{a}</td>
                          <td style={{ color: b === "✗" ? "var(--err)" : b.includes("✓") || b === "Illimité" ? "var(--ok)" : "var(--warn)" }}>{b}</td>
                          <td style={{ color: c === "✗" ? "var(--err)" : "var(--ok)" }}>{c}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ══ MAISON ══ */}
            {page === "maison" && (
              <div>
                <div className="steps">
                  {["Pays", "Projet", "Qualité", "Résultat"].map((s, i) => (
                    <div key={i} className={`step${step > i ? " done" : ""}`}>
                      <div className="step-n">{i + 1}</div><br />{s}
                    </div>
                  ))}
                </div>

                {step === 1 && (
                  <div>
                    <div className="card">
                      <div className="card-title">Choisissez votre pays</div>
                      <div className="cnt-grid">
                        {COUNTRIES.map(c => (
                          <div key={c.code} className={`cnt${cc === c.code ? " sel" : ""}`} onClick={() => setCc(c.code)}>
                            <div className="cnt-flag">{c.flag}</div>
                            <div className="cnt-name">{c.name}</div>
                            <div className="cnt-cur">{c.cur}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <button className="btn btn-gold" style={{ marginTop: 10 }} onClick={() => setStep(2)}>Continuer →</button>
                  </div>
                )}

                {step === 2 && (
                  <div>
                    <div className="card">
                      <div className="card-title">Décrivez votre projet</div>
                      <div className="fg" style={{ marginBottom: 12 }}>
                        <label>Description libre</label>
                        <textarea value={mForm.desc} onChange={e => setMForm(f => ({ ...f, desc: e.target.value }))} placeholder="Ex : Maison 120m², 3 chambres, cuisine ouverte, terrain plat…" />
                      </div>
                      <div className="fg2">
                        <div className="fg"><label>Longueur (m)</label><input type="number" value={mForm.l} onChange={e => setMForm(f => ({ ...f, l: parseFloat(e.target.value) || 12 })) } /></div>
                        <div className="fg"><label>Largeur (m)</label><input type="number" value={mForm.w} onChange={e => setMForm(f => ({ ...f, w: parseFloat(e.target.value) || 10 }))} /></div>
                        <div className="fg"><label>Étages</label><select value={mForm.fl} onChange={e => setMForm(f => ({ ...f, fl: parseInt(e.target.value) }))}><option value={1}>R+0</option><option value={2}>R+1</option><option value={3}>R+2</option></select></div>
                        <div className="fg"><label>Toiture</label><select value={mForm.roofType} onChange={e => setMForm(f => ({ ...f, roofType: e.target.value }))}><option value="pitched">Inclinée</option><option value="flat">Plate</option></select></div>
                        <div className="fg"><label>Budget cible</label><input type="number" value={mForm.budget} onChange={e => setMForm(f => ({ ...f, budget: e.target.value }))} placeholder="Optionnel" /></div>
                        <div className="fg"><label>Salles de bain</label><input type="number" value={mForm.sdb} onChange={e => setMForm(f => ({ ...f, sdb: parseInt(e.target.value) || 2 }))} /></div>
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                      <button className="btn btn-out" onClick={() => setStep(1)}>← Retour</button>
                      <button className="btn btn-gold" onClick={() => setStep(3)}>Continuer →</button>
                    </div>
                  </div>
                )}

                {step === 3 && (
                  <div>
                    <div className="card">
                      <div className="card-title">Qualité des matériaux</div>
                      <div className="q-row">
                        {[
                          { k: "eco", c: "var(--ok)", n: "Économique", sub: "Parpaing · Tôle · Finitions simples", d: "−20 à −25%" },
                          { k: "std", c: "var(--gold)", n: "Standard", sub: "Brique · Tuile béton · Alu standard", d: "Référence" },
                          { k: "pre", c: "#D4857A", n: "Premium", sub: "Béton cellulaire · Tuile cuite · Double vitrage", d: "+25 à +40%" },
                        ].map(q => (
                          <div key={q.k} className={`q-card${qual === q.k ? " sel" : ""}`} onClick={() => setQual(q.k)}>
                            <div style={{ fontSize: 20, marginBottom: 5, color: q.c }}>◉</div>
                            <div className="q-name" style={{ color: q.c }}>{q.n}</div>
                            <div className="q-sub">{q.sub}</div>
                            <div className="q-delta" style={{ color: q.c }}>{q.d}</div>
                          </div>
                        ))}
                      </div>
                      <div className="note" style={{ fontSize: 11 }}>
                        {qual === "eco" && "ÉCONOMIQUE — Parpaing creux · Tôle bac acier · Béton poli · PVC économique"}
                        {qual === "std" && "STANDARD — Brique creuse · Tuile béton · Fenêtres alu · Carrelage · Câble NF · PVC standard"}
                        {qual === "pre" && "PREMIUM — Béton cellulaire · Tuile terre cuite · Double vitrage · Parquet ou marbre · Domotique"}
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                      <button className="btn btn-out" onClick={() => setStep(2)}>← Retour</button>
                      <button className="btn btn-gold" onClick={launchMaison}>⚡ Lancer l'estimation</button>
                    </div>
                  </div>
                )}

                {step === 4 && (
                  <div>
                    {computing && <div style={{ textAlign: "center", padding: 32 }}><div className="spinner" /><div style={{ fontSize: 11, color: "var(--dim)", marginTop: 6 }}>PHG IA calcule votre estimation…</div></div>}
                    {mResult && !computing && (
                      <div>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                          <div style={{ fontFamily: "'Cinzel',serif", fontSize: 13, color: "var(--gold)" }}>Résultat · Estimation PHG</div>
                          <span className="badge b-est">V1</span>
                        </div>
                        <div className="tabs">
                          {["mat", "cout", "recs"].map(t => (
                            <div key={t} className={`tab${mTab === t ? " active" : ""}`} onClick={() => setMTab(t)}>
                              {t === "mat" ? "Matériaux" : t === "cout" ? "Coût" : "Recommandations IA"}
                            </div>
                          ))}
                        </div>

                        {mTab === "mat" && (
                          <div>
                            <table className="mat-tbl">
                              <thead><tr><th>Matériau</th><th>Quantité</th><th>Unité</th><th>P.U.</th><th>Total</th></tr></thead>
                              <tbody>
                                {(CAN.fullMaterials(plan) ? mResult.materials : mResult.materials.slice(0, 3)).map((m, i) => (
                                  <tr key={i}>
                                    <td>{m.n}</td><td>{fmt(m.q)}</td><td>{m.u}</td>
                                    <td>{fmt(m.pu, 2)} {mResult.cur}</td>
                                    <td style={{ color: "var(--gold)", fontWeight: 600 }}>{fmt(m.t)} {mResult.cur}</td>
                                  </tr>
                                ))}
                                {!CAN.fullMaterials(plan) && (
                                  <tr><td colSpan={5} style={{ textAlign: "center", color: "var(--dim)", padding: 8 }}>… +{mResult.materials.length - 3} matériaux masqués</td></tr>
                                )}
                              </tbody>
                            </table>
                            {!CAN.fullMaterials(plan) && (
                              <div className="lock-overlay">
                                <div className="lock-icon">🔒</div>
                                <div className="lock-title">Détail complet des matériaux</div>
                                <div className="lock-sub">Le plan Gratuit affiche les 3 premiers matériaux.<br />Passez à PRO (5€/mois) pour voir les {mResult.materials.length} matériaux avec quantités et prix exacts.</div>
                                <button className="btn btn-gold" onClick={() => setPage("abonnement")}>Débloquer PRO — 5 €/mois</button>
                              </div>
                            )}
                          </div>
                        )}

                        {mTab === "cout" && (
                          <div>
                            <div className="result-wrap">
                              <div className="cost-line"><span className="cost-lbl">Matériaux</span><span>{fmt(mResult.matCost)} {mResult.cur}</span></div>
                              <div className="cost-line"><span className="cost-lbl">Main d'œuvre</span><span>{fmt(mResult.labCost)} {mResult.cur}</span></div>
                              <div className="cost-line"><span className="cost-lbl">Logistique</span><span>{fmt(mResult.logCost)} {mResult.cur}</span></div>
                              <div className="cost-line"><span className="cost-lbl">Marge risque (8%)</span><span>{fmt(mResult.risk)} {mResult.cur}</span></div>
                              <div className="cost-line total"><span>TOTAL ESTIMÉ</span><span>{fmt(mResult.total)} {mResult.cur}</span></div>
                            </div>
                            {mResult.budget > 0 && (
                              <div className={`alert ${mResult.total > mResult.budget ? "alert-warn" : "alert-ok"}`}>
                                {mResult.total > mResult.budget
                                  ? `Dépassement : +${fmt(mResult.total - mResult.budget)} ${mResult.cur} vs votre budget. Optez pour la qualité Éco ou réduisez la surface.`
                                  : `Dans le budget — marge disponible : ${fmt(mResult.budget - mResult.total)} ${mResult.cur}`}
                              </div>
                            )}
                          </div>
                        )}

                        {mTab === "recs" && (
                          CAN.recs(plan) ? (
                            <div>
                              <div className="score-grid">
                                {[{ l: "Budget", v: mResult.bs }, { l: "Construct.", v: 88 }, { l: "Matériaux", v: qual === "pre" ? 94 : qual === "eco" ? 77 : 85 }, { l: "Optim.", v: 80 }].map((s, i) => (
                                  <div key={i} className="sc-item"><div className="sc-num" style={{ color: scColor(s.v) }}>{s.v}</div><div className="sc-lbl">{s.l}</div></div>
                                ))}
                              </div>
                              <div style={{ textAlign: "center", marginBottom: 12 }}>
                                <div style={{ fontFamily: "'Cinzel',serif", fontSize: 28, color: scColor(mResult.gs) }}>{mResult.gs}<span style={{ fontSize: 13, color: "var(--dim)" }}>/100</span></div>
                                <div style={{ fontSize: 11, color: "var(--dim)" }}>Score global PHG IA</div>
                              </div>
                              {mResult.budget > 0 && mResult.total > mResult.budget && (
                                <div className="rec-item"><div className="rec-hdr"><span className="rec-ttl">Dépassement budgétaire</span><span className="sev-h">HIGH</span></div><div className="rec-body">Le coût dépasse votre budget. <strong>→</strong> Réduire la surface ou opter pour la qualité Éco.<br /><span className="gain">💰 {fmt(Math.round((mResult.total - mResult.budget) * 0.35))} {mResult.cur} récupérables</span></div></div>
                              )}
                              <div className="rec-item"><div className="rec-hdr"><span className="rec-ttl">Optimisation circuits</span><span className="sev-l">LOW</span></div><div className="rec-body">Regrouper cuisine et salles de bain réduit les réseaux. <strong>→</strong> Économie plomberie estimée 3 à 5%.<br /><span className="gain">💰 {fmt(Math.round(mResult.total * 0.04))} {mResult.cur} d'économie possible</span></div></div>
                              {qual === "pre" && (cc === "CI" || cc === "SN") && (
                                <div className="rec-item"><div className="rec-hdr"><span className="rec-ttl">Premium en zone tropicale</span><span className="sev-m">MEDIUM</span></div><div className="rec-body">Certains matériaux premium sont sensibles à l'humidité tropicale. <strong>→</strong> Vérifier disponibilité locale.</div></div>
                              )}
                            </div>
                          ) : (
                            <div className="lock-overlay">
                              <div className="lock-icon">🔒</div>
                              <div className="lock-title">Recommandations IA</div>
                              <div className="lock-sub">Accédez aux recommandations personnalisées, score de projet et optimisations avec le plan PRO à 5€/mois.</div>
                              <button className="btn btn-gold" onClick={() => setPage("abonnement")}>Activer PRO →</button>
                            </div>
                          )
                        )}

                        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                          <button className="btn btn-out" onClick={() => { setStep(1); setMResult(null); }}>← Nouveau</button>
                          <button className="btn btn-gold" onClick={pdfClick}>📄 Exporter PDF</button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* ══ INFRA ══ */}
            {page === "infra" && (
              !CAN.infra(plan) ? (
                <div className="lock-overlay" style={{ marginTop: 0 }}>
                  <div className="lock-icon">🔒</div>
                  <div className="lock-title">Module Infrastructure</div>
                  <div className="lock-sub">Ce module est réservé aux abonnés PRO et ELITE.<br />Passez à PRO (5€/mois) pour concevoir ponts, routes et bâtiments publics.</div>
                  <button className="btn btn-gold" onClick={() => setPage("abonnement")}>Voir les offres →</button>
                </div>
              ) : (
                <div>
                  <div className="card">
                    <div className="card-title">Type d'infrastructure</div>
                    <div className="inf-grid">
                      {[{ k: "pont", i: "🌉", n: "Pont", s: "Béton armé · Acier · Rural" }, { k: "route", i: "🛣️", n: "Route", s: "Bitume · Pavé · Piste" }, { k: "bat", i: "🏫", n: "Bâtiment public", s: "École · Dispensaire" }].map(t => (
                        <div key={t.k} className={`inf-card${infType === t.k ? " sel" : ""}`} onClick={() => setInfType(t.k)}>
                          <div style={{ fontSize: 26, marginBottom: 5 }}>{t.i}</div>
                          <div style={{ fontWeight: 600, marginBottom: 2 }}>{t.n}</div>
                          <div style={{ fontSize: 10, color: "var(--dim)" }}>{t.s}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="card">
                    <div className="card-title">Paramètres du pont</div>
                    <div className="fg2">
                      <div className="fg"><label>Longueur (m)</label><input type="number" value={iForm.l} onChange={e => setIForm(f => ({ ...f, l: parseFloat(e.target.value) || 50 }))} /></div>
                      <div className="fg"><label>Largeur (m)</label><input type="number" value={iForm.w} onChange={e => setIForm(f => ({ ...f, w: parseFloat(e.target.value) || 8 }))} /></div>
                      <div className="fg"><label>Structure</label><select value={iForm.type} onChange={e => setIForm(f => ({ ...f, type: e.target.value }))}><option value="beton">Béton armé</option><option value="acier">Charpente acier</option><option value="local">Locale simplifiée</option></select></div>
                      <div className="fg"><label>Nombre de piles</label><input type="number" value={iForm.piers} onChange={e => setIForm(f => ({ ...f, piers: parseInt(e.target.value) || 2 }))} /></div>
                      <div className="fg"><label>Hauteur piles (m)</label><input type="number" value={iForm.pHeight} onChange={e => setIForm(f => ({ ...f, pHeight: parseFloat(e.target.value) || 4 }))} /></div>
                      <div className="fg"><label>Pays</label><select value={iForm.country} onChange={e => setIForm(f => ({ ...f, country: e.target.value }))}><option value="FR">🇫🇷 France</option><option value="CI">🇨🇮 Côte d'Ivoire</option><option value="CH">🇨🇭 Suisse</option></select></div>
                    </div>
                    <button className="btn btn-gold" style={{ marginTop: 8 }} onClick={launchInfra}>⚡ Calculer l'infrastructure</button>
                  </div>
                  {iComputing && <div style={{ textAlign: "center", padding: 24 }}><div className="spinner" /></div>}
                  {iResult && !iComputing && (
                    <div>
                      <div className="alert alert-warn">Pré-estimation indicative — ne remplace pas une étude structurelle certifiée.</div>
                      <div className="tabs" style={{ marginTop: 12 }}>
                        {["mat", "cout"].map(t => <div key={t} className={`tab${iTab === t ? " active" : ""}`} onClick={() => setITab(t)}>{t === "mat" ? "Matériaux" : "Coût"}</div>)}
                      </div>
                      {iTab === "mat" && (
                        <table className="mat-tbl">
                          <thead><tr><th>Poste</th><th>Quantité</th><th>Unité</th><th>P.U.</th><th>Total</th></tr></thead>
                          <tbody>{iResult.materials.map((m, i) => <tr key={i}><td>{m.n}</td><td>{m.q}</td><td>{m.u}</td><td>{m.pu} {iResult.cur}</td><td style={{ color: "var(--gold)", fontWeight: 600 }}>{fmt(m.t)} {iResult.cur}</td></tr>)}</tbody>
                        </table>
                      )}
                      {iTab === "cout" && (
                        <div className="result-wrap">
                          <div className="cost-line"><span className="cost-lbl">Béton armé</span><span>{fmt(iResult.betonC)} {iResult.cur}</span></div>
                          <div className="cost-line"><span className="cost-lbl">Acier armature</span><span>{fmt(iResult.acierC)} {iResult.cur}</span></div>
                          <div className="cost-line"><span className="cost-lbl">Main d'œuvre</span><span>{fmt(iResult.labC)} {iResult.cur}</span></div>
                          <div className="cost-line"><span className="cost-lbl">Logistique (6%)</span><span>{fmt(iResult.logC)} {iResult.cur}</span></div>
                          <div className="cost-line"><span className="cost-lbl">Marge risque (15%)</span><span>{fmt(iResult.risk)} {iResult.cur}</span></div>
                          <div className="cost-line total"><span>TOTAL ESTIMÉ</span><span>{fmt(iResult.total)} {iResult.cur}</span></div>
                        </div>
                      )}
                      <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                        <button className="btn btn-out" onClick={() => setIResult(null)}>← Modifier</button>
                        <button className="btn btn-gold" onClick={pdfClick}>📄 Dossier technique PDF</button>
                      </div>
                    </div>
                  )}
                </div>
              )
            )}

            {/* ══ ANALYSE ══ */}
            {page === "analyse" && (
              !CAN.analyse(plan) ? (
                <div className="lock-overlay" style={{ marginTop: 0 }}>
                  <div className="lock-icon">🔒</div>
                  <div className="lock-title">Analyse de plan IA</div>
                  <div className="lock-sub">L'analyse de plan (PDF, photo, croquis) est disponible dès le plan PRO à 5€/mois.<br />L'IA lit votre plan, détecte les erreurs et optimise les coûts.</div>
                  <button className="btn btn-gold" onClick={() => setPage("abonnement")}>Activer PRO →</button>
                </div>
              ) : (
                <div>
                  <div className="card">
                    <div className="card-title">Uploadez votre plan</div>
                    {!uploaded ? (
                      <div className="upload-z" onClick={() => setUploaded(true)}>
                        <div style={{ fontSize: 28, color: "var(--dim)", marginBottom: 8 }}>📁</div>
                        <div style={{ fontSize: 11, color: "var(--dim)" }}>Cliquez pour uploader<br /><span style={{ fontSize: 10 }}>PDF · Image · Croquis · DWG</span></div>
                      </div>
                    ) : (
                      <div style={{ background: "var(--panel2)", border: "1px solid var(--border)", borderRadius: "var(--r)", padding: "8px 12px", fontSize: 11, color: "var(--gold)", marginBottom: 10 }}>
                        📁 plan_maison_projet.pdf — prêt pour analyse
                      </div>
                    )}
                    {uploaded && (
                      <div>
                        <div className="fg2" style={{ marginTop: 10 }}>
                          <div className="fg"><label>Pays</label><select value={anCC} onChange={e => setAnCC(e.target.value)}><option value="CI">🇨🇮 Côte d'Ivoire</option><option value="FR">🇫🇷 France</option><option value="CH">🇨🇭 Suisse</option></select></div>
                          <div className="fg"><label>Type de fichier</label><select><option value="pdf">PDF</option><option value="image">Image / Photo</option></select></div>
                        </div>
                        <button className="btn btn-gold" style={{ marginTop: 8 }} onClick={launchAnalyse}>🧠 Analyser le plan</button>
                      </div>
                    )}
                  </div>
                  {anComputing && <div style={{ textAlign: "center", padding: 24 }}><div className="spinner" /><div style={{ fontSize: 11, color: "var(--dim)", marginTop: 6 }}>L'IA analyse votre plan…</div></div>}
                  {anResult && !anComputing && (
                    <div>
                      <div className="card">
                        <div className="card-title">Données extraites</div>
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10 }}>
                          <div className="kpi"><div className="kpi-lbl">Surface</div><div className="kpi-val">{anResult.surf}</div><div className="kpi-sub">m²</div></div>
                          <div className="kpi"><div className="kpi-lbl">Pièces</div><div className="kpi-val">{anResult.rooms}</div><div className="kpi-sub">détectées</div></div>
                          <div className="kpi"><div className="kpi-lbl">Ouvertures</div><div className="kpi-val">{anResult.openings}</div><div className="kpi-sub">portes & fenêtres</div></div>
                        </div>
                      </div>
                      <div className="card">
                        <div className="card-title">Diagnostic IA</div>
                        {[
                          { t: "Couloir surdimensionné", s: "medium", obs: "Le couloir occupe ~15% de la surface (norme 12%). Réduire pour gagner de l'espace habitable." },
                          { t: "Pièces humides éloignées", s: "medium", obs: "Cuisine et salle de bain non groupées → surcoût plomberie estimé +8%." },
                          { t: "Orientation solaire", s: "low", obs: "Le plan respecte bien l'orientation solaire. Aucune correction nécessaire." },
                        ].map((r, i) => (
                          <div key={i} className="rec-item">
                            <div className="rec-hdr"><span className="rec-ttl">{r.t}</span><span className={`sev-${r.s}`}>{r.s.toUpperCase()}</span></div>
                            <div className="rec-body">{r.obs}</div>
                          </div>
                        ))}
                      </div>
                      <div className="card">
                        <div className="card-title">Estimation automatique</div>
                        <div className="result-wrap">
                          <div className="cost-line"><span className="cost-lbl">Fourchette basse (Éco)</span><span>{fmt(anResult.eco)} {anResult.cur}</span></div>
                          <div className="cost-line"><span className="cost-lbl">Estimation standard</span><span>{fmt(anResult.std)} {anResult.cur}</span></div>
                          <div className="cost-line total"><span>Fourchette haute (Premium)</span><span>{fmt(anResult.pre)} {anResult.cur}</span></div>
                        </div>
                        <button className="btn btn-gold" style={{ marginTop: 12, width: "100%" }} onClick={pdfClick}>📄 Rapport complet PDF</button>
                      </div>
                    </div>
                  )}
                </div>
              )
            )}

            {/* ══ PROJETS ══ */}
            {page === "projets" && (
              <div className="card">
                <div className="card-title">Mes projets</div>
                <table className="main-tbl">
                  <thead><tr><th>Nom</th><th>Type</th><th>Pays</th><th>Qualité</th><th>Coût estimé</th><th>Statut</th><th></th></tr></thead>
                  <tbody>
                    {projects.map(p => (
                      <tr key={p.id}>
                        <td style={{ fontWeight: 600 }}>{p.name}</td>
                        <td><span className={`badge ${p.type === "house" ? "b-house" : "b-bridge"}`}>{p.type === "house" ? "🏠 Maison" : "🌉 Pont"}</span></td>
                        <td>{p.country}</td>
                        <td><span className={`badge b-${p.qual}`}>{p.qual}</span></td>
                        <td style={{ fontFamily: "'Cinzel',serif", color: "var(--gold)" }}>{p.cost ? fmt(p.cost) + " €" : "—"}</td>
                        <td><span className={`badge ${p.status === "estimated" ? "b-est" : "b-draft"}`}>{p.status}</span></td>
                        <td><button className="btn btn-out btn-sm" onClick={() => { if (p.type === "bridge" && !CAN.infra(plan)) alert("🔒 Détail pont réservé au plan PRO."); else setPage("maison"); }}>Détail</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {plan === "free" && <div className="note">Plan Gratuit : 1 projet actif. Passez à PRO pour des projets illimités.</div>}
              </div>
            )}

            {/* ══ ABONNEMENT ══ */}
            {page === "abonnement" && (
              <div>
                <div className="card" style={{ textAlign: "center", padding: 22, marginBottom: 16 }}>
                  <div style={{ fontFamily: "'Cinzel',serif", fontSize: 10, color: "var(--gold)", letterSpacing: 2, marginBottom: 5 }}>VOTRE PLAN ACTUEL</div>
                  <div style={{ fontFamily: "'Cinzel',serif", fontSize: 22 }}>{planLabel[plan]}</div>
                </div>
                <div className="plan-grid">
                  {[
                    { k: "free", name: "Gratuit", amount: "0", period: "/mois", africa: "", feats: ["1 projet", "Estimation globale", "3 matériaux aperçu", "✗ Export PDF", "✗ Infrastructure"], btns: [{ l: "Rester gratuit", cls: "btn-out", p: "free" }] },
                    { k: "pro", name: "Pro", amount: "5", period: "€/mois", africa: "🌍 5€/mois partout", feats: ["Projets illimités", "Matériaux détaillés", "Export PDF PHG", "Ponts + Plans", "Recommandations IA"], featured: true, chip: "POPULAIRE", btns: [{ l: "Activer PRO — 5 €", cls: "btn-gold", p: "pro" }] },
                    { k: "elite", name: "Elite", amount: "20", period: "€/mois", africa: "🌍 Afrique : 10 €/mois", feats: ["Tout du Pro", "Multi-clients / devis", "Marque blanche", "API + BIM/DXF", "Support prioritaire"], btns: [{ l: "Europe 20€", cls: "btn-out", p: "elite" }, { l: "Afrique 10€", cls: "btn-gold", p: "elite-africa" }] },
                  ].map(pl => (
                    <div key={pl.k} className={`plan-card${pl.featured ? " featured" : ""}`}>
                      {pl.chip && <div className="plan-chip">{pl.chip}</div>}
                      <div className="plan-name">{pl.name}</div>
                      <div><span className="plan-amount">{pl.amount}</span><span className="plan-period"> {pl.period}</span></div>
                      <div className="plan-africa">{pl.africa}</div>
                      <ul className="plan-feats">
                        {pl.feats.map((f, i) => <li key={i}><span className={f.startsWith("✗") ? "fno" : "fok"}>{f.startsWith("✗") ? "✗" : "✓"}</span>{f.replace("✗ ", "")}</li>)}
                      </ul>
                      <div style={{ display: "flex", gap: 6 }}>
                        {pl.btns.map((b, i) => <button key={i} className={`btn ${b.cls} btn-sm`} style={{ flex: 1 }} onClick={() => activatePlan(b.p)}>{b.l}</button>)}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="note">Paiements sécurisés via Stripe. Résiliation à tout moment. Le tarif Afrique s'applique aux pays du continent africain (détecté automatiquement ou sélectionnable manuellement).</div>
              </div>
            )}

          </div>
        </div>
      </div>
    </>
  );
}

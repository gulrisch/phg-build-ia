# Instructions pour Claude Code — PHG BUILD IA

## Contexte du projet
PHG BUILD IA est une plateforme de construction intelligente francophone développée par Goulia Frédéric Richard / PHG Éditions (Saint-Julien-en-Genevois).

## Stack technique
- Backend : Python 3.10+ / FastAPI / SQLAlchemy / PostgreSQL
- Frontend : React 18 / Vite / JSX / HTML5 Canvas
- Paiement : Stripe + CinetPay (Mobile Money Afrique)
- Export : ReportLab (PDF) + Pillow (PNG)
- Déploiement : Railway (backend) + Vercel (frontend)

## Identité visuelle PHG
- Or principal : #C9A84C
- Noir : #0A0A0A
- Typographies : Cinzel (titres), Montserrat (corps)
- Glyph : 𓂀

## Ce qui est fait
Voir README.md — 70% du projet est opérationnel.

## Priorités de développement (dans l'ordre)
1. Backend FastAPI complet avec auth JWT
2. Stripe live (3 plans : 5€ PRO / 20€ ELITE / 10€ Afrique)
3. CinetPay pour Orange Money / MTN / Wave
4. Connexion frontend ↔ backend
5. Tests et déploiement

## Ne jamais modifier
- La logique de calcul des prix dans App.jsx (validée)
- Les 45 pays et leurs prix
- L'identité visuelle PHG
